#!/bin/bash -e

./scripts/_archive-all.sh